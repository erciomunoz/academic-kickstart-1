library(foreign)
library(sf)
library(raster)
library(dplyr)
library(spData)
library(spDataLarge)
library(tmap)

DATA <- read.dta("Output/dta/LAC_clean_Table1_for_R.dta")
temp_shapefile <- tempfile()
download.file("https://opendata.arcgis.com/datasets/a21fdb46d23e4ef896f31475217cbb08_1.zip", temp_shapefile)
unzip(temp_shapefile)
MAP <- read_sf('99bfd9e7-bb42-4728-87b5-07f8c8ac631c2020328-1-1vef4ev.lu5nk.shp')
LATAM<-DATA$countrys
MAPLATAM<- MAP %>% filter(MAP$CNTRY_NAME %in% LATAM)
MAPLATAM <- rename(MAPLATAM, "countrys" = "CNTRY_NAME")
MAPLATAM$countrys<-as.character(MAPLATAM$countrys)
DATA$countrys<-as.character(DATA$countrys)
MAPLATAM <- MAPLATAM %>% left_join(DATA, by=c("countrys"))
MAPLATAM$countrys

m1<- tm_shape(MAPLATAM) +
  tm_polygons("country_beta_1", title = 'Upward Mobility', 
              legend.reverse = T,  legend.is.portrait = T,palette=c("#bd0026","#f03b20","#fd8d3c","#fecc5c","#ffffb2"),
              border.col = "gray60", breaks = quantile(MAPLATAM$country_beta_1, probs = seq(0, 1, 0.2), na.rm = T)) +
  tm_layout(frame=F,
            legend.position = c(0.25,0.15), outer.margins = c(0,-0.4,0,-0.5),
            legend.format = list(text.separator = "to",text.align="center",
                                 digits=2, text.to.columns=T))+
  tm_text("countrys", size=0.4, col="black", shadow = T, just = "bottom", 
          xmod = c(0,-0.001,0,-0.2,
                   0.05,-1.2,0,1.6,
                   0.2,-1.1,-1.4,-0.2,
                   .8,-0.8,0,0,1.1,
                   0,-0.3,-0.9,0,1.7,
                   0,0.1),
          ymod = c(0,0,0,0,
                   0,-0.2,0.4,0.2,
                   0,-0.3,-0.3,-.45,
                   0.3,0.1,0,0,-0.1,
                   0,0,-0.5,0.2,0.3,
                   0,0))


m3<- tm_shape(MAPLATAM) +
  tm_polygons("country_beta_3", title = 'Downward Mobility', 
              legend.reverse = F,  legend.is.portrait = T,palette=c("#ffffb2","#fecc5c","#fd8d3c","#f03b20","#bd0026"),
              border.col = "gray60", breaks = quantile(MAPLATAM$country_beta_3, probs = seq(0, 1, 0.2), na.rm = T)) +
  tm_layout(frame=F,
            legend.position = c(0.25,0.15), outer.margins = c(0,-0.4,0,-0.5),
            legend.format = list(text.separator = "to",text.align="center",
                                 digits=3, text.to.columns=T))+
  tm_text("countrys", size=0.4, col="black", shadow = T, just = "bottom", 
          xmod = c(0,-0.001,0,-0.2,
                   0.05,-1.2,0,1.6,
                   0.2,-1.1,-1.4,-0.2,
                   .8,-0.8,0,0,1.1,
                   0,-0.3,-0.9,0,1.7,
                   0,0.1),
          ymod = c(0,0,0,0,
                   0,-0.2,0.4,0.2,
                   0,-0.3,-0.3,-.45,
                   0.3,0.1,0,0,-0.1,
                   0,0,-0.5,0.2,0.3,
                   0,0))


tmap_save(m1, "Figure_6a.pdf", width=1200, height=1080, asp=0)
tmap_save(m3, "Figure_6b.pdf", width=1200, height=1080, asp=0)
