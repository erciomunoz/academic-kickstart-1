rm(list=ls())
library("rgdal")
library("leaflet")
library("tmap")
library("tmaptools")
library("viridis")
library("haven")
library("dplyr")
library("plyr")
library("spatialEco")
library("sf")

setwd('')
output_path <- ""
LCD_path <- ""

shape_file <- readOGR('world_geolev1_2019.shp')
shape_file <- shape_file[!shape_file@data$CNTRY_NAME=="Cuba", ]
shape_file <- shape_file[!shape_file@data$CNTRY_NAME=="Suriname",]

shape_file_suriname <- readOGR('geo1_sr2004_2012.shp')

shape_file_cuba <- readOGR('geo1_cu2002_2012.shp')

shape_file1<- rbind(shape_file_suriname,shape_file_cuba)
colnames(shape_file1@data)[5]<- "BPL_CODE"
shape_file<- rbind(shape_file,shape_file1)

sum(shape_file@data$CNTRY_NAME == 'Suriname', na.rm=TRUE)
sum(shape_file@data$CNTRY_NAME == 'Cuba', na.rm=TRUE)

countries <- readOGR('world_countries_2020.shp')

latin_america <- subset(shape_file, CNTRY_NAME == "Argentina" | 
                          CNTRY_NAME == "Bolivia" | 
                          CNTRY_NAME == "Brazil" | 
                          CNTRY_NAME == "Chile" | 
                          CNTRY_NAME == "Colombia" | 
                          CNTRY_NAME == "Costa Rica" | 
                          CNTRY_NAME == "Cuba" | 
                          CNTRY_NAME == "Dominican Republic" | 
                          CNTRY_NAME == "Ecuador" | 
                          CNTRY_NAME == "El Salvador" | 
                          CNTRY_NAME == "Guatemala" | 
                          CNTRY_NAME == "Haiti" | 
                          CNTRY_NAME == "Honduras" | 
                          CNTRY_NAME == "Mexico" | 
                          CNTRY_NAME == "Nicaragua" | 
                          CNTRY_NAME == "Panama" | 
                          CNTRY_NAME == "Paraguay" | 
                          CNTRY_NAME == "Peru" | 
                          CNTRY_NAME == "Uruguay" | 
                          CNTRY_NAME == "Venezuela" |
                          CNTRY_NAME == "Jamaica" |
                          CNTRY_NAME == "Trinidad and Tobago" |
                          CNTRY_NAME == "Suriname" |
                          CNTRY_NAME == "Saint Lucia" )

country_la <- subset(countries, CNTRY_NAME == "Argentina" | 
                       CNTRY_NAME == "Bolivia" | 
                       CNTRY_NAME == "Brazil" | 
                       CNTRY_NAME == "Chile" | 
                       CNTRY_NAME == "Colombia" | 
                       CNTRY_NAME == "Costa Rica" | 
                       CNTRY_NAME == "Cuba" | 
                       CNTRY_NAME == "Dominican Republic" | 
                       CNTRY_NAME == "Ecuador" | 
                       CNTRY_NAME == "El Salvador" | 
                       CNTRY_NAME == "Guatemala" | 
                       CNTRY_NAME == "Haiti" | 
                       CNTRY_NAME == "Honduras" | 
                       CNTRY_NAME == "Mexico" | 
                       CNTRY_NAME == "Nicaragua" | 
                       CNTRY_NAME == "Panama" | 
                       CNTRY_NAME == "Paraguay" | 
                       CNTRY_NAME == "Peru" | 
                       CNTRY_NAME == "Uruguay" | 
                       CNTRY_NAME == "Venezuela" |
                       CNTRY_NAME == "Jamaica" |
                       CNTRY_NAME == "Trinidad & Tobago" |
                       CNTRY_NAME == "Suriname" |
                       CNTRY_NAME == "St. Lucia")
                      

#primary estimation
LAC_clean_districts <- read_dta(paste0(LCD_path, "/LAC_clean_districts_geolev1.dta"))
data <- as.data.frame(LAC_clean_districts %>% select(geolev1, upward, downward)) %>%
  dplyr::rename(GEOLEVEL1 = geolev1) %>% mutate(upward = round(upward,3),
                                                downward = round(downward,3))

for (i in 1:length(data$GEOLEVEL1)) {
  if (nchar(data$GEOLEVEL1[i]) == 5) {
    data$GEOLEVEL1[i] = paste0(0, data$GEOLEVEL1[i])
  }
}

data$upward[data$upward < 0] <- 0
data$upward[data$upward > 1] <- 1
data$downward[data$downward < 0] <- 0
data$downward[data$downward > 1] <- 1

latin_america@data <- plyr::join(latin_america@data, data, by = "GEOLEVEL1")
colnames(latin_america@data) <- c("CNTRY_NAME", "ADMIN_NAME", "CNTRY_CODE",
                                  "GEOLEVEL1", "BPL_CODE", "Upward mobility",
                                  "Downward mobility")

tmap_mode("plot")

# Upward primary
tmap_la_upward <- tm_shape(latin_america) + 
  tm_fill(col="Upward mobility", palette = "viridis", colorNA = "gray",  legend.reverse = T,
          border.col = "gray60", breaks = quantile(latin_america$`Upward mobility`, probs = seq(0, 1, 0.1), na.rm = T),
          legend.show = TRUE, textNA = "No Data") +
  tm_layout(legend.title.size = 1.5, frame = FALSE,
            legend.position = c(0.1,0.25), legend.format = list(text.separator = "to",text.align="left",
                                                                digits=2, text.to.columns=F))
tmap_la_upward <- tmap_la_upward + tm_shape(country_la) +
  tm_borders(lwd=0.6, col = "black")
tmap_save(tm = tmap_la_upward, filename = paste0(output_path,"Figure_10.jpg"))

# Downward primary
tmap_la_downward <- tm_shape(latin_america) + 
  tm_fill(col="Downward mobility", palette = "-viridis", colorNA = "gray",  legend.reverse = F,
          border.col = "gray60", breaks = quantile(latin_america$`Downward mobility`, probs = seq(0, 1, 0.1), na.rm = T),
          legend.show = TRUE, textNA = "No Data") +
  tm_layout(legend.title.size = 1.5, frame = FALSE,
            legend.position = c(0.1,0.25), legend.format = list(text.separator = "to",text.align="left",
                                                                digits=2, text.to.columns=F))
tmap_la_downward <- tmap_la_downward + tm_shape(country_la) +
  tm_borders(lwd=0.6, col = "black")
tmap_save(tm = tmap_la_downward, filename = paste0(output_path,"Figure_11.jpg"))

